// supabaseConfig.js - Configuración de Supabase (NO SUBIR A GIT)
// ⚠️ Este archivo está en .gitignore - es SOLO LOCAL

// 1. Ve a tu proyecto Supabase: https://supabase.com/dashboard
// 2. Copia estos valores de "Settings > API"

export const SUPABASE_URL = 'https://ptjkepxsjqyejkynjewc.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB0amtlcHhzanF5ZWpreW5qZXdjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNDkyNDksImV4cCI6MjA3ODYyNTI0OX0._OPoGxMknS9VTzC16Zx_euobimiW1dzQnbpT5Ae3WQw';

// IMPORTANTE:
// - NUNCA subas este archivo a GitHub/GitLab
// - Para otro PC: copia este archivo manualmente (USB, etc.)
// - La ANON KEY es pública (segura) pero mejor mantenerla privada por si cambias políticas RLS
