<html>
<head>
<title>Ejemplo de operaciones</title>
</head>
<body>
<h1>Ejemplo de operaciones aritméticas en PHP</h1>
<?php
$a = 8;
$b = 3;
echo $a + $b, "<br>";
echo $a - $b, "<br>";
echo $a * $b, "<br>";
echo $a / $b, "<br>";
echo $a % $b, "<br>";
$b--;
echo $b, "<br>";
?>
</body>
</html>