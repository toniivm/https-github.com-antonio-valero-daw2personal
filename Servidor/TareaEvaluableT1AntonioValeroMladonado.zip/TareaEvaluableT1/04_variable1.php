<html>
<head>
<title></title>
</head>
<body>
<h1>Primer ejemplo de Variables</h1>
<p>
<?php
$Name = "Miguel";
echo "Hola <b>$Name</b>, encantado de conocerte";
echo "Este es mi primer programa en PHP.<br>";
echo "Estoy aprendiendo a usar variables.<br>";
?>
</p>
</body>
</html>
