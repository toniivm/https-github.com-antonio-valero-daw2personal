<!DOCTYPE html>
<html>
<head>
 <title>Sustitución de Variables</title>
</head>
<body>
 <h1>Sustitución de Variables</h1>
 <?php
 // Definir tres variables enteras
$numero1 = 5;
$numero2 = 10;
$numero3 = 15;

// Definir un string que incorpore las variables
$mensaje = "Los números son $numero1, $numero2 y $numero3.";

// Mostrar el mensaje en pantalla
echo $mensaje;
 ?>
</body>
</html>
