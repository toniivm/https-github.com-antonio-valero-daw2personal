<html>
<head>
<title></title>
</head>
<body>
<h1>Break en la ventana del navegador con signo \</h1>
<p>
<?php
$Name = "Miguel";
echo "Hola <b>$Name</b>, encantado de conocerte<br>\n";
echo "Gracias por venir!\n";
?>
</p>
</body>
</html>